package m5s;

public interface Shape {
	
	 double calculateArea(double one, double two);
	 double calculateShape(double one, double two);

}
