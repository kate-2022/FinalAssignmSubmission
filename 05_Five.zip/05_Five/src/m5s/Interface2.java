package m5s;

public interface Interface2 {
	
/*
 * Nothing to see here, this is just a marker interface!
 */

}
