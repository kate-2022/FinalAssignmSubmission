package m5s;

public class Main {

	public static void main(String[] args) {
		
		 ChestNutTree chestNutTree = new ChestNutTree("squarrose");

	}

}
