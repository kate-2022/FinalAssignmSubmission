package m5s;

public class Tree {

	public String species;
	public int age;
	public double height;
	
	public Tree(String species, int age, double height) {
		System.out.println("Parent class constructor is called..");
	}
}
