package m5s;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {

		
		BankAccount account= new BankAccount();
		account.bankTransaction();

	}

}
