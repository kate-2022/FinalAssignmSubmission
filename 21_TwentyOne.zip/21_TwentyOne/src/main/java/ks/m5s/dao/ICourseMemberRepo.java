package ks.m5s.dao;

import org.springframework.data.repository.CrudRepository;

import ks.m5s.bo.CourseMember;


public interface ICourseMemberRepo extends CrudRepository<CourseMember, Integer>{

}
