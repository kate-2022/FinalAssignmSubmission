package ks.m5s.service;

import ks.m5s.bo.CourseMember;

public interface ICourseMemberManagementService {
	
	public String registerNewMember(CourseMember newMember);

}
