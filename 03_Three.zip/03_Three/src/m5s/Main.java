package m5s;


public class Main {
	

	public static void main(String[] args) {
		 	 
		Number number = new Number();
		number.acceptNumber();
		 
		 
	}

}
